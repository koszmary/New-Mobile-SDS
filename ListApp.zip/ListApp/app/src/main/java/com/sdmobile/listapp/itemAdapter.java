package com.sdmobile.listapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class itemAdapter extends BaseAdapter {

    LayoutInflater mInflater;
    String[] items;
    String[] prices;
    String[] descriptions;

    public itemAdapter(Context c, String[] i, String[] p, String[] d){
        items = i;
        prices = p;
        descriptions = d;
        mInflater = LayoutInflater.from(c);
    }

    @Override  // Dodaj override
    public int getCount() {
        return items.length;
    }

    @Override
    public Object getItem(int i) {
        return items[i];
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        ViewHolder holder;

        if (view == null) {
            view = mInflater.inflate(R.layout.listview_det, viewGroup, false);
            holder = new ViewHolder();
            holder.nameTextView = view.findViewById(R.id.NameTextview);
            holder.descriptionTextView = view.findViewById(R.id.Description);
            holder.priceTextView = view.findViewById(R.id.priceTextview);
            view.setTag(holder);
        } else {
            holder = (ViewHolder) view.getTag();
        }

        holder.nameTextView.setText(items[i]);
        holder.descriptionTextView.setText(descriptions[i]);
        holder.priceTextView.setText(prices[i]);

        return view;
    }

    // Wzorzec ViewHolder dla lepszej wydajności
    private static class ViewHolder {
        TextView nameTextView;
        TextView descriptionTextView;
        TextView priceTextView;
    }
}